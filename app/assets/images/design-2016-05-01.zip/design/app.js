function mainPage(){
	$('.content').load('mainpage-content.html');
	$('.bottom-container').empty();
}
function mapPage(){
	$('.content').load('map-content.html', function(){
		setMapHolderSize();
		startMap();
		$('.bottom-container').load('work-panel.html');
	});
}
function setMapHolderSize(){
	workPanelSize = 70;
	headerSize = 60
	$('.map-holder').css('height', $(window).height() - (headerSize + workPanelSize))
}
 
function changeLocationToMap(){
	mapPage();
	$('.dashboard li').removeClass('active');
	$('#map').parent('li').addClass('active');
}
$('#map').click(function(){
	changeLocationToMap();
});

$('#main').click(function(){
	mainPage();
	$('.dashboard li').removeClass('active');
	$(this).parent('li').addClass('active')
});


$(window).resize(function(){
	setMapHolderSize();
})

$(document).ready(function(){
	mainPage();
})

