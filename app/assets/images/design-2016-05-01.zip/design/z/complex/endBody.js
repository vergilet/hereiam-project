document.writeln("<script src='complex/js/app.js' type='text/javascript'></script>");
document.writeln("<script src='complex/js/chat.js' type='text/javascript'></script>");