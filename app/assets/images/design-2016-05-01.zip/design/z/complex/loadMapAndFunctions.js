$("body").append("<script type='text/javascript' src='complex/js/map.js' ></script>");
