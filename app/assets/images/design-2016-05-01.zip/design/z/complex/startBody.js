document.writeln("<script src='complex/complete-solutions/jquery/js/jquery.js' type='text/javascript'></script>");
document.writeln("<script src='complex/complete-solutions/bootstrap/js/bootstrap.min.js' type='text/javascript'></script>");
document.writeln("<script src='complex/complete-solutions/mmenu/js/jquery.mmenu.js' type='text/javascript'></script>");
